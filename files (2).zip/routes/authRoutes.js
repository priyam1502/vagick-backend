const router = require('express').Router();
const authController = require('../controllers/auth.controller');

router.post('/login', authController.login);
router.post('/verify', authController.verify);
router.post('/set-password', authController.setPassword);
router.post('/reset-password', authController.resetPassword);

module.exports = router;